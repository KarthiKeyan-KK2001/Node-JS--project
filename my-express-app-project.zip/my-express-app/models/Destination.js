const mongoose = require('mongoose');

const DestinationSchema = new mongoose.Schema({
    accountId: { type: String, required: true },
    url: { type: String, required: true },
    httpMethod: { type: String, required: true },
    headers: { type: Map, of: String, required: true }
});

module.exports = mongoose.model('Destination', DestinationSchema);

const mongoose = require('mongoose');

const AccountSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    accountId: { type: String, unique: true },
    accountName: { type: String, required: true },
    appSecretToken: { type: String, required: true },
    website: { type: String }
});

module.exports = mongoose.model('Account', AccountSchema);


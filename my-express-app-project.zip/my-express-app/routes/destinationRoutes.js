const express = require('express');
const Destination = require('../models/Destination');
const router = express.Router();

// Create Destination
router.post('/', async (req, res) => {
    try {
        const destination = new Destination(req.body);
        await destination.save();
        res.status(201).send(destination);
    } catch (err) {
        res.status(400).send(err);
    }
});

// Read Destination
router.get('/:id', async (req, res) => {
    try {
        const destination = await Destination.findById(req.params.id);
        if (!destination) return res.status(404).send('Destination not found');
        res.send(destination);
    } catch (err) {
        res.status(400).send(err);
    }
});

// Update Destination
router.put('/:id', async (req, res) => {
    try {
        const destination = await Destination.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!destination) return res.status(404).send('Destination not found');
        res.send(destination);
    } catch (err) {
        res.status(400).send(err);
    }
});

// Delete Destination
router.delete('/:id', async (req, res) => {
    try {
        const destination = await Destination.findByIdAndDelete(req.params.id);
        if (!destination) return res.status(404).send('Destination not found');
        res.send('Destination deleted');
    } catch (err) {
        res.status(400).send(err);
    }
});

// Get Destinations for an Account
router.get('/account/:accountId', async (req, res) => {
    try {
        const destinations = await Destination.find({ accountId: req.params.accountId });
        res.send(destinations);
    } catch (err) {
        res.status(400).send(err);
    }
});

module.exports = router;

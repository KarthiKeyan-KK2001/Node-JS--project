const express = require('express');
const Account = require('../models/Account');
const Destination = require('../models/Destination');
const axios = require('axios');
const router = express.Router();

// Handle Incoming Data
router.post('/incoming_data', async (req, res) => {
    const token = req.headers['cl-x-token'];
    if (!token) return res.status(401).send({ message: 'Un Authenticate' });

    try {
        const account = await Account.findOne({ appSecretToken: token });
        if (!account) return res.status(401).send({ message: 'Un Authenticate' });

        const destinations = await Destination.find({ accountId: account.accountId });
        if (!destinations.length) return res.status(404).send({ message: 'No destinations found for this account' });

        destinations.forEach(destination => {
            const { url, httpMethod, headers } = destination;
            const config = { headers };
            if (httpMethod.toLowerCase() === 'get') {
                axios.get(url, { params: req.body, ...config }).catch(err => console.error(err));
            } else {
                axios[httpMethod.toLowerCase()](url, req.body, config).catch(err => console.error(err));
            }
        });

        res.send({ message: 'Data forwarded to destinations' });
    } catch (err) {
        res.status(400).send(err);
    }
});

module.exports = router;

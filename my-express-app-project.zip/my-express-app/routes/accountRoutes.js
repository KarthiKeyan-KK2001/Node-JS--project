const express = require('express');
const mongoose = require('mongoose');
const Account = require('../models/Account');
const router = express.Router();

// Create Account
router.post('/', async (req, res) => {
    try {
        const { email, accountName, website } = req.body;
        const appSecretToken = require('crypto').randomBytes(5).toString('hex');
        const accountId = new mongoose.Types.ObjectId().toString(); // Unique ID generation
        const account = new Account({ email, accountId, accountName, appSecretToken, website });
        await account.save();
        res.status(201).send(account);
    } catch (err) {
        res.status(400).send(err);
    }
});

// Additional CRUD operations...

module.exports = router;

